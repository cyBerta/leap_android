import android, time

droid = android.Android()

for x in range(0, 6):
	droid.makeToast("Hello from Python 2.7 for Android")
	time.sleep(5)