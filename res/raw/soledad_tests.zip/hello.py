import android, time 


droid = android.Android()

droid.makeToast("running soledad tests on Python2.6")
time.sleep(3)
try:
  import test_backends
  droid.makeToast("test_backends successful")
  time.sleep(4)
except:
  droid.makeToast("test_backends failed")
  time.sleep(4)
try:  
  import test_couch
  droid.makeToast("test_couch successful")
  time.sleep(4)
except:
  droid.makeToast("test_couch failed")
  time.sleep(4)
  
try:  
  import test_crypto
  droid.makeToast("test_crypto successful")
  time.sleep(4)
except:
  droid.makeToast("test_crypto failed")
  time.sleep(4)
try:  
  import test_document
  droid.makeToast("test_document successful")
  time.sleep(4)
except:
  droid.makeToast("test_document failed")
  time.sleep(4)
try:  
  import test_http_app
  droid.makeToast("test_http_app successful")
  time.sleep(4)
except:
  droid.makeToast("test_http_app failed")
  time.sleep(4)
try:  
  import test_http_client
  droid.makeToast("test_http_client successful")
  time.sleep(4)
except:
  droid.makeToast("test_http_client failed")
  time.sleep(4)
try:  
  import test_http_database
  droid.makeToast("test_http_database successful")
  time.sleep(4)
except:
  droid.makeToast("test_http_database failed")
  time.sleep(4)
try:  
  import test_https
  droid.makeToast("test_https successful")
  time.sleep(4)
except:
  droid.makeToast("test_https failed")
  time.sleep(4)
try:  
  import test_open
  droid.makeToast("test_open successful")
  time.sleep(4)
except:
  droid.makeToast("test_open failed")
  time.sleep(4)
try:  
  import test_remote_sync_target
  droid.makeToast("test_remote_sync_target successful")
  time.sleep(4)
except:
  droid.makeToast("test_remote_sync_target failed")
  time.sleep(4)
try:  
  import test_soledad
  droid.makeToast("test_soledad successful")
  time.sleep(4)
except:
  droid.makeToast("test_soledad failed")
  time.sleep(4)
try:  
  import test_sqlcipher
  droid.makeToast("test_sqlcipher successful")
  time.sleep(4)
except:
  droid.makeToast("test_sqlcipher failed")
  time.sleep(4)

try:  
  import test_sqlite_backend
  droid.makeToast("test_sqlite_backend successful")
  time.sleep(4)
except:
  droid.makeToast("test_sqlite_backend failed")
  time.sleep(4)
try:  
  import test_synch
  droid.makeToast("test_synch successful")
  time.sleep(4)
except:
  droid.makeToast("test_synch failed")
  time.sleep(4)


droid.makeToast("Beam me up, Scotty, tests are over")
time.sleep(4)
