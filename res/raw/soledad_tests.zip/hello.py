import android, time, traceback


droid = android.Android()

droid.makeToast("running soledad tests on Python2.6")
time.sleep(2)
try:
  import test_backends
  droid.makeToast("test_backends successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_backends failed: \n \n " + e)
  time.sleep(5)
try:  
  import test_couch
  droid.makeToast("test_couch successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_couch failed: \n \n " + e)
  time.sleep(5)
  
try:  
  import test_crypto
  droid.makeToast("test_crypto successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_crypto failed: \n \n " + e)
  time.sleep(5)
try:  
  import test_document
  droid.makeToast("test_document successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_document failed: \n \n " + e)
  time.sleep(5)
try:  
  import test_http_app
  droid.makeToast("test_http_app successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_http_app failed: \n \n " + e)
  time.sleep(5)
try:  
  import test_http_client
  droid.makeToast("test_http_client successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_http_client failed: \n \n " + e)
  time.sleep(5)
try:  
  import test_http_database
  droid.makeToast("test_http_database successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_http_database failed \n \n " + e)
  time.sleep(5)
try:  
  import test_https
  droid.makeToast("test_https successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_https failed \n \n " + e)
  time.sleep(5)
try:  
  import test_open
  droid.makeToast("test_open successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_open failed \n \n " + e)
  time.sleep(5)
try:  
  import test_remote_sync_target
  droid.makeToast("test_remote_sync_target successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_remote_sync_target failed \n \n " + e)
  time.sleep(5)
try:  
  import test_soledad
  droid.makeToast("test_soledad successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_soledad failed \n \n " + e)
  time.sleep(5)
try:  
  import test_sqlcipher
  droid.makeToast("test_sqlcipher successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_sqlcipher failed \n \n " + e)
  time.sleep(5)

try:  
  import test_sqlite_backend
  droid.makeToast("test_sqlite_backend successful")
  time.sleep(5)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("test_sqlite_backend failed \n \n " + e)
  time.sleep(5)
try:  
  import test_sync
  droid.makeToast("test_sync successful")
  time.sleep(2)
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("Test_sync failed: \n \n " + e)
  time.sleep(5)


droid.makeToast("Beam me up, Scotty, tests are over")
time.sleep(2)
