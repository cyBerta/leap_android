import android, time, traceback, nose, unittest


droid = android.Android()





droid.makeToast("Running LEAP's unit tests on Python2.6")
time.sleep(2)

try:  

  import sys
  errorOut = sys.stderr 
  fsock = open('/data/data/se.leap.bitmaskclient/files/test_s/log.txt', 'w')
  sys.stderr = fsock
  success=nose.run(argv=['--where="/data/data/se.leap.bitmaskclient/files"', '--verbosity=3', '--exe', '--nocapture'])
  if success:
    droid.makeToast("Success - All unit tests passed.")
    droid.log("success")
  else:
    droid.makeToast("Unit tests failed. See /data/data/se.bitmaskclient/files/test_s/log.txt")
    time.sleep(2)
    droid.log("failure")
  time.sleep(2)
  sys.stderr = errorOut
  fsock.close()
except Exception:
  e = traceback.format_exc()
  droid.log(e)
  droid.makeToast("Unit testing failed. \n \n " + e)
  time.sleep(5)
  if 'errorOut' in locals():
    sys.stderr = errorOut
  if 'fsock' in locals():
    fsock.close()
   

time.sleep(2)
